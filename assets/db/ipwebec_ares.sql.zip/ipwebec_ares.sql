-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 18-03-2019 a las 08:01:33
-- Versión del servidor: 10.2.22-MariaDB-log
-- Versión de PHP: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ipwebec_ares`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `actividad`
--

CREATE TABLE `actividad` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `fecha_desde` datetime DEFAULT NULL,
  `fecha_hasta` datetime DEFAULT NULL,
  `cci` int(11) DEFAULT NULL,
  `ccd` datetime DEFAULT NULL,
  `cwi` int(11) DEFAULT NULL,
  `cwd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cae`
--

CREATE TABLE `cae` (
  `id` int(11) NOT NULL,
  `unidad_id` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `cci` int(11) DEFAULT NULL,
  `ccd` datetime DEFAULT NULL,
  `cwi` int(11) DEFAULT NULL,
  `cwd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cae`
--

INSERT INTO `cae` (`id`, `unidad_id`, `nombre`, `cci`, `ccd`, `cwi`, `cwd`) VALUES
(1, 1, 'QUITO', NULL, NULL, 1, '2019-03-04 17:15:20'),
(4, 1, 'GUAYAQUIL', 1, '2019-03-04 17:17:03', 1, '2019-03-04 17:17:19'),
(5, 1, 'CUENCA', 1, '2019-03-09 14:57:34', NULL, NULL),
(6, 1, 'MACHALA', 1, '2019-03-09 14:57:44', NULL, NULL),
(7, 1, 'LOJA', 1, '2019-03-09 14:57:53', NULL, NULL),
(11, 1, 'PASTAZA', 1, '2019-03-09 14:59:42', NULL, NULL),
(13, 1, 'COCA', 1, '2019-03-09 15:00:06', NULL, NULL),
(14, 1, 'GALAPAGOS', 1, '2019-03-11 14:10:37', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria_menu`
--

CREATE TABLE `categoria_menu` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `codigo` varchar(45) DEFAULT NULL,
  `icono` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `categoria_menu`
--

INSERT INTO `categoria_menu` (`id`, `nombre`, `codigo`, `icono`) VALUES
(1, 'Administración', 'administracion', '<i class=\"fab fa-app-store-ios\"></i>'),
(2, 'TTHH', 'tthh', '<i class=\"fe fe-user\"></i>'),
(3, 'Configuración', 'configuracion', '<i class=\"fe fe-settings\"></i>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comision`
--

CREATE TABLE `comision` (
  `id` int(11) NOT NULL,
  `personal_id` int(11) NOT NULL,
  `numero` int(11) DEFAULT NULL,
  `fecha_inicio` datetime DEFAULT NULL,
  `fecha_fin` datetime DEFAULT NULL,
  `estado` enum('P','A','R','F','I') DEFAULT 'P',
  `situacion_previa` text DEFAULT NULL,
  `actividad_ejecutada` text DEFAULT NULL,
  `actividad_pendiente` text DEFAULT NULL,
  `observacion` text DEFAULT NULL,
  `cci` int(11) DEFAULT NULL,
  `ccd` datetime DEFAULT NULL,
  `cwi` int(11) DEFAULT NULL,
  `cwd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comision_tipo_mantenimiento`
--

CREATE TABLE `comision_tipo_mantenimiento` (
  `comision_id` int(11) NOT NULL,
  `tipo_mantenimiento_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_comision`
--

CREATE TABLE `detalle_comision` (
  `id` int(11) NOT NULL,
  `comision_id` int(11) NOT NULL,
  `personal_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estacion`
--

CREATE TABLE `estacion` (
  `id` int(11) NOT NULL,
  `cae_id` int(11) NOT NULL,
  `nominativo` varchar(20) DEFAULT NULL,
  `nombre` varchar(500) DEFAULT NULL,
  `direccion` varchar(500) DEFAULT NULL,
  `telefono_fijo` varchar(50) DEFAULT NULL,
  `telefono_movil` varchar(50) DEFAULT NULL,
  `cci` int(11) DEFAULT NULL,
  `ccd` datetime DEFAULT NULL,
  `cwi` int(11) DEFAULT NULL,
  `cwd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_civil`
--

CREATE TABLE `estado_civil` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `cci` int(11) DEFAULT NULL,
  `ccd` datetime DEFAULT NULL,
  `cwi` int(11) DEFAULT NULL,
  `cwd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `estado_civil`
--

INSERT INTO `estado_civil` (`id`, `nombre`, `cci`, `ccd`, `cwi`, `cwd`) VALUES
(1, 'SOLTERO(A)', NULL, NULL, NULL, NULL),
(2, 'CASADO(A)', 1, '2019-03-09 16:50:28', NULL, NULL),
(3, 'DIVORCIADO(A)', 1, '2019-03-09 16:50:43', NULL, NULL),
(4, 'VIUDO(A)', 1, '2019-03-09 16:50:55', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fuerza`
--

CREATE TABLE `fuerza` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `logo` varchar(45) DEFAULT NULL,
  `cci` int(11) DEFAULT NULL,
  `ccd` datetime DEFAULT NULL,
  `cwi` int(11) DEFAULT NULL,
  `cwd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `fuerza`
--

INSERT INTO `fuerza` (`id`, `nombre`, `logo`, `cci`, `ccd`, `cwi`, `cwd`) VALUES
(1, 'EJÉRCITO', '11.jpg', NULL, NULL, 1, '2019-03-09 15:25:48'),
(3, 'FUERZA AÉREA', '32.jpg', 1, '2019-03-05 10:51:49', 1, '2019-03-09 15:32:28'),
(4, 'ARMADA', '4.jpg', 1, '2019-03-09 15:16:17', 1, '2019-03-09 15:24:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `funcion`
--

CREATE TABLE `funcion` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `cci` int(11) DEFAULT NULL,
  `ccd` datetime DEFAULT NULL,
  `cwi` int(11) DEFAULT NULL,
  `cwd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `funcion`
--

INSERT INTO `funcion` (`id`, `nombre`, `cci`, `ccd`, `cwi`, `cwd`) VALUES
(1, 'FUNCION', NULL, NULL, NULL, NULL),
(2, 'TÉCNICO EN SISTEMA DE CONMUTACIÓN', 1, '2019-03-11 10:06:24', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grado`
--

CREATE TABLE `grado` (
  `id` int(11) NOT NULL,
  `fuerza_id` int(11) NOT NULL,
  `orden` int(11) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `abreviatura` varchar(45) DEFAULT NULL,
  `cci` int(11) DEFAULT NULL,
  `ccd` datetime DEFAULT NULL,
  `cwi` int(11) DEFAULT NULL,
  `cwd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `grado`
--

INSERT INTO `grado` (`id`, `fuerza_id`, `orden`, `nombre`, `abreviatura`, `cci`, `ccd`, `cwi`, `cwd`) VALUES
(2, 3, 1, 'CORONEL', 'CRNL.', NULL, '2019-03-05 11:33:52', 1, '2019-03-09 16:26:36'),
(3, 1, 1, 'CORONEL', 'CRNL.', 1, '2019-03-09 15:37:52', NULL, NULL),
(4, 1, 2, 'TENIENTE CORONEL', 'TCRN.', 1, '2019-03-09 15:38:34', 1, '2019-03-09 15:39:07'),
(7, 1, 3, 'MAYOR', 'MAYO.', 1, '2019-03-09 15:39:34', NULL, NULL),
(10, 1, 4, 'CAPITÁN', 'CAPT.', 1, '2019-03-09 15:41:54', NULL, NULL),
(11, 1, 5, 'TENIENTE', 'TNTE.', 1, '2019-03-09 15:42:21', NULL, NULL),
(12, 1, 6, 'SUBTENIENTE', 'SUBT.', 1, '2019-03-09 15:42:44', NULL, NULL),
(13, 1, 7, 'SUBOFICIAL MAYOR', 'SUBM.', 1, '2019-03-09 15:44:15', 1, '2019-03-09 16:21:21'),
(14, 1, 8, 'SUBOFICIAL PRIMERO', 'SUBP.', 1, '2019-03-09 15:44:48', 1, '2019-03-09 16:22:24'),
(15, 1, 9, 'SUBOFICIAL SEGUNDO', 'SUBS.', 1, '2019-03-09 16:20:17', 1, '2019-03-09 16:22:32'),
(16, 1, 10, 'SARGENTO PRIMERO', 'SGOP.', 1, '2019-03-09 16:23:05', NULL, NULL),
(17, 1, 11, 'SARGENTO SEGUNDO', 'SGOS.', 1, '2019-03-09 16:23:43', NULL, NULL),
(18, 1, 11, 'CABO PRIMERO', 'CBOP.', 1, '2019-03-09 16:24:15', NULL, NULL),
(19, 1, 12, 'CABO SEGUNDO', 'CBOS.', 1, '2019-03-09 16:24:50', 1, '2019-03-09 16:25:16'),
(20, 1, 113, 'SOLDADO', 'SLDO.', 1, '2019-03-09 16:25:46', NULL, NULL),
(21, 3, 2, 'TENIENTE CORONEL', 'TCRN.', 1, '2019-03-09 16:26:56', NULL, NULL),
(22, 3, 3, 'MAYOR', 'MAYO.', 1, '2019-03-09 16:27:16', NULL, NULL),
(23, 3, 4, 'CAPITAN', 'CAPT.', 1, '2019-03-09 16:27:58', NULL, NULL),
(24, 3, 5, 'TENIENTE', 'TNTE.', 1, '2019-03-09 16:28:45', NULL, NULL),
(25, 3, 6, 'SUBTENIENTE', 'SUBT.', 1, '2019-03-09 16:29:43', NULL, NULL),
(26, 3, 7, 'SUBOFICIAL MAYOR', 'SUBM.', 1, '2019-03-09 16:31:18', NULL, NULL),
(27, 3, 8, 'SUBOFICIAL SEGUNDO', 'SUBS.', 1, '2019-03-09 16:32:19', NULL, NULL),
(28, 3, 9, 'SARGENTO PRIMERO', 'SGOP.', 1, '2019-03-09 16:32:47', NULL, NULL),
(29, 3, 10, 'SARGENTO SEGUNDO', 'SGOS.', 1, '2019-03-09 16:34:21', NULL, NULL),
(30, 3, 11, 'CABO PRIMERO', 'CBOP.', 1, '2019-03-09 16:34:46', NULL, NULL),
(31, 3, 12, 'CABO SEGUNDO', 'CBOS.', 1, '2019-03-09 16:35:13', NULL, NULL),
(32, 3, 13, 'SOLDADO', 'SLDO.', 1, '2019-03-09 16:35:38', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `categoria_menu_id` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `codigo` varchar(45) DEFAULT NULL,
  `icono` varchar(255) DEFAULT NULL,
  `ruta` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `menu`
--

INSERT INTO `menu` (`id`, `categoria_menu_id`, `nombre`, `codigo`, `icono`, `ruta`) VALUES
(1, 3, 'Categorías Menús', 'categoriasMenus', '<i class=\"fas fa-circle-notch\"></i>', 'CategoriasMenus/index'),
(2, 3, 'Menús', 'menus', '<i class=\"fas fa-circle-notch\"></i>', 'Menus/index'),
(3, 2, 'Personal', 'personal', '<i class=\"fas fa-circle-notch\"></i>', 'Personales/index'),
(4, 1, 'Unidad', 'unidad', '<i class=\"fas fa-circle-notch\"></i>', 'Unidades/formulario'),
(5, 1, 'CAE', 'cae', '<i class=\"fas fa-circle-notch\"></i>', 'Caes/index'),
(6, 1, 'Fuerzas', 'fuerzas', '<i class=\"fas fa-circle-notch\"></i>', 'Fuerzas/index'),
(7, 1, 'Funciones', 'funciones', '<i class=\"fas fa-circle-notch\"></i>', 'Funciones/index'),
(8, 1, 'Estados Civiles', 'estadosCiviles', '<i class=\"fas fa-circle-notch\"></i>', 'EstadosCiviles/index');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `parte`
--

CREATE TABLE `parte` (
  `id` int(11) NOT NULL,
  `sistema_id` int(11) NOT NULL,
  `tipo_existencia_id` int(11) NOT NULL,
  `fecha` datetime DEFAULT NULL,
  `novedad` text DEFAULT NULL,
  `seguimiento` text DEFAULT NULL,
  `requerimiento_solucion` text DEFAULT NULL,
  `es_solucionado` enum('NO','SI') DEFAULT NULL,
  `cci` int(11) DEFAULT NULL,
  `ccd` datetime DEFAULT NULL,
  `cwi` int(11) DEFAULT NULL,
  `cwd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pase`
--

CREATE TABLE `pase` (
  `id` int(11) NOT NULL,
  `personal_id` int(11) NOT NULL,
  `cae_id` int(11) NOT NULL,
  `seccion_id` int(11) NOT NULL,
  `sistema_id` int(11) NOT NULL,
  `fecha_ingreso` date DEFAULT NULL,
  `fecha_salida` date DEFAULT NULL,
  `cci` int(11) DEFAULT NULL,
  `ccd` datetime DEFAULT NULL,
  `cwi` int(11) DEFAULT NULL,
  `cwd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfil`
--

CREATE TABLE `perfil` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfil_menu`
--

CREATE TABLE `perfil_menu` (
  `id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `autorizacion` varchar(45) DEFAULT NULL,
  `escritura` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal`
--

CREATE TABLE `personal` (
  `id` int(11) NOT NULL,
  `fuerza_id` int(11) NOT NULL,
  `grado_id` int(11) NOT NULL,
  `estado_civil_id` int(11) NOT NULL,
  `funcion_id` int(11) NOT NULL,
  `apellido` varchar(100) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `tipo_identificacion` enum('C','P') DEFAULT 'C',
  `numero_identificacion` varchar(15) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `telefono_fijo` varchar(50) DEFAULT NULL,
  `telefono_movil` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `tipo_sangre` varchar(5) DEFAULT NULL,
  `foto` varchar(45) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `cci` int(11) DEFAULT NULL,
  `ccd` datetime DEFAULT NULL,
  `cwi` int(11) DEFAULT NULL,
  `cwd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `personal`
--

INSERT INTO `personal` (`id`, `fuerza_id`, `grado_id`, `estado_civil_id`, `funcion_id`, `apellido`, `nombre`, `tipo_identificacion`, `numero_identificacion`, `fecha_nacimiento`, `telefono_fijo`, `telefono_movil`, `email`, `tipo_sangre`, `foto`, `direccion`, `cci`, `ccd`, `cwi`, `cwd`) VALUES
(1, 3, 2, 1, 0, 'QUIMBITA', 'MARCELO', 'C', '0102030405', '1984-02-02', '', '', 'mail@mail.com', 'O+', '0102030405.jpg', 'LATACUNGA', NULL, NULL, 1, '2019-03-05 16:41:19'),
(2, 1, 19, 2, 0, 'RIVAS IZA ', 'MARCO VINICIO', 'C', '1002970968', '1988-02-28', '032802-279', '0986013482', 'marcorivas1988@gmail.com', 'O+', '', 'LATACUNGA', 1, '2019-03-09 16:58:16', NULL, NULL),
(3, 1, 4, 2, 0, 'ENRIQUEZ', 'JOSE', 'C', '1778905678', '1970-11-22', '023454456', '0967123456', 'enriquez@gmail.com', 'B+', '', 'QUITO', 1, '2019-03-10 20:34:19', NULL, NULL),
(4, 3, 22, 3, 0, 'ARIAS', 'JUAN', 'C', '1234543210', '1975-12-03', '023234543', '0912323409', 'arias@gmail.com', 'O+', '', 'QUITO', 1, '2019-03-10 20:36:35', NULL, NULL),
(5, 1, 14, 2, 0, 'ZAPATA', 'RAFAEL', 'C', '1723456789', '1980-07-04', '023345654', '0987654532', 'zapata@gmail.com', 'O+', '', 'QUITO', 1, '2019-03-10 20:38:08', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `seccion`
--

CREATE TABLE `seccion` (
  `id` int(11) NOT NULL,
  `estacion_id` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `cci` int(11) DEFAULT NULL,
  `ccd` datetime DEFAULT NULL,
  `cwi` int(11) DEFAULT NULL,
  `cwd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sistema`
--

CREATE TABLE `sistema` (
  `id` int(11) NOT NULL,
  `seccion_id` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `cci` int(11) DEFAULT NULL,
  `ccd` datetime DEFAULT NULL,
  `cwi` int(11) DEFAULT NULL,
  `cwd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_existencia`
--

CREATE TABLE `tipo_existencia` (
  `id` int(11) NOT NULL,
  `cae_id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `propiedad` varchar(100) DEFAULT NULL,
  `cci` int(11) DEFAULT NULL,
  `ccd` datetime DEFAULT NULL,
  `cwi` int(11) DEFAULT NULL,
  `cwd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_mantenimiento`
--

CREATE TABLE `tipo_mantenimiento` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `unidad`
--

CREATE TABLE `unidad` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `abreviatura` varchar(45) DEFAULT NULL,
  `logo` varchar(45) DEFAULT NULL,
  `direccion` varchar(500) DEFAULT NULL,
  `telefono_fijo` varchar(100) DEFAULT NULL,
  `telefono_movil` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `cci` int(11) DEFAULT NULL,
  `ccd` datetime DEFAULT NULL,
  `cwi` int(11) DEFAULT NULL,
  `cwd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `unidad`
--

INSERT INTO `unidad` (`id`, `nombre`, `abreviatura`, `logo`, `direccion`, `telefono_fijo`, `telefono_movil`, `email`, `cci`, `ccd`, `cwi`, `cwd`) VALUES
(1, 'GRUPO DE SISTEMAS INFORMÁTICOS, COMUNICACIONES Y GUERRA ELECTRÓNICA CONJUNTO', 'GRUSICOMGE', '16.jpg', 'LA RECOLECTA - QUITO', '023484854', '0986013482', 'grusicomge@gmail.com', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `personal_id` int(11) NOT NULL,
  `es_superadmin` enum('S','N') DEFAULT 'N',
  `usuario` varchar(45) DEFAULT NULL,
  `clave` varchar(255) DEFAULT NULL,
  `estado` enum('A','I') DEFAULT 'I',
  `cci` int(11) DEFAULT NULL,
  `ccd` datetime DEFAULT NULL,
  `cwi` int(11) DEFAULT NULL,
  `cwd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `personal_id`, `es_superadmin`, `usuario`, `clave`, `estado`, `cci`, `ccd`, `cwi`, `cwd`) VALUES
(1, 1, 'S', 'webmaster', '54e4dde95ad582ac5e60e7fa6aff1d2b204044bab8328f929942450a77d00d7bbec955a870af90519703d3e599b330425d9296f6ea9b6728b68abd8cd1f89802JfMrcU5W6wXzhUuvk3nqg/IGa/E8m0qeuRUIzvw9RaQ=', 'A', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_perfil`
--

CREATE TABLE `usuario_perfil` (
  `usuario_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `actividad`
--
ALTER TABLE `actividad`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cae`
--
ALTER TABLE `cae`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_cae_unidad_idx` (`unidad_id`);

--
-- Indices de la tabla `categoria_menu`
--
ALTER TABLE `categoria_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `comision`
--
ALTER TABLE `comision`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_comision_personal1_idx` (`personal_id`);

--
-- Indices de la tabla `comision_tipo_mantenimiento`
--
ALTER TABLE `comision_tipo_mantenimiento`
  ADD PRIMARY KEY (`comision_id`,`tipo_mantenimiento_id`),
  ADD KEY `fk_comision_has_tipo_mantenimiento_tipo_mantenimiento1_idx` (`tipo_mantenimiento_id`),
  ADD KEY `fk_comision_has_tipo_mantenimiento_comision1_idx` (`comision_id`);

--
-- Indices de la tabla `detalle_comision`
--
ALTER TABLE `detalle_comision`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_detalle_comision_comision1_idx` (`comision_id`),
  ADD KEY `fk_detalle_comision_personal1_idx` (`personal_id`);

--
-- Indices de la tabla `estacion`
--
ALTER TABLE `estacion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_estacion_cae1_idx` (`cae_id`);

--
-- Indices de la tabla `estado_civil`
--
ALTER TABLE `estado_civil`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `fuerza`
--
ALTER TABLE `fuerza`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `funcion`
--
ALTER TABLE `funcion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `grado`
--
ALTER TABLE `grado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_grado_fuerza1_idx` (`fuerza_id`);

--
-- Indices de la tabla `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_menu_categoria_menu1_idx` (`categoria_menu_id`);

--
-- Indices de la tabla `parte`
--
ALTER TABLE `parte`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_parte_sistema1_idx` (`sistema_id`),
  ADD KEY `fk_parte_tipo_existencia1_idx` (`tipo_existencia_id`);

--
-- Indices de la tabla `pase`
--
ALTER TABLE `pase`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pase_personal1_idx` (`personal_id`),
  ADD KEY `fk_pase_cae1_idx` (`cae_id`),
  ADD KEY `fk_pase_seccion1_idx` (`seccion_id`),
  ADD KEY `fk_pase_sistema1_idx` (`sistema_id`);

--
-- Indices de la tabla `perfil`
--
ALTER TABLE `perfil`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `perfil_menu`
--
ALTER TABLE `perfil_menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_perfil_menu_perfil1_idx` (`perfil_id`),
  ADD KEY `fk_perfil_menu_menu1_idx` (`menu_id`);

--
-- Indices de la tabla `personal`
--
ALTER TABLE `personal`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_personal_fuerza1_idx` (`fuerza_id`),
  ADD KEY `fk_personal_grado1_idx` (`grado_id`),
  ADD KEY `fk_personal_estado_civil1_idx` (`estado_civil_id`),
  ADD KEY `fk_personal_funcion1_idx` (`funcion_id`);

--
-- Indices de la tabla `seccion`
--
ALTER TABLE `seccion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_seccion_estacion1_idx` (`estacion_id`);

--
-- Indices de la tabla `sistema`
--
ALTER TABLE `sistema`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_sistema_seccion1_idx` (`seccion_id`);

--
-- Indices de la tabla `tipo_existencia`
--
ALTER TABLE `tipo_existencia`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_tipo_existencia_cae1_idx` (`cae_id`);

--
-- Indices de la tabla `tipo_mantenimiento`
--
ALTER TABLE `tipo_mantenimiento`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `unidad`
--
ALTER TABLE `unidad`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_usuario_personal1_idx` (`personal_id`);

--
-- Indices de la tabla `usuario_perfil`
--
ALTER TABLE `usuario_perfil`
  ADD PRIMARY KEY (`usuario_id`,`perfil_id`),
  ADD KEY `fk_usuario_has_perfil_perfil1_idx` (`perfil_id`),
  ADD KEY `fk_usuario_has_perfil_usuario1_idx` (`usuario_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `actividad`
--
ALTER TABLE `actividad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cae`
--
ALTER TABLE `cae`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `categoria_menu`
--
ALTER TABLE `categoria_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `comision`
--
ALTER TABLE `comision`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `detalle_comision`
--
ALTER TABLE `detalle_comision`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `estacion`
--
ALTER TABLE `estacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `estado_civil`
--
ALTER TABLE `estado_civil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `fuerza`
--
ALTER TABLE `fuerza`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `funcion`
--
ALTER TABLE `funcion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `grado`
--
ALTER TABLE `grado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de la tabla `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `parte`
--
ALTER TABLE `parte`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pase`
--
ALTER TABLE `pase`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `perfil`
--
ALTER TABLE `perfil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `perfil_menu`
--
ALTER TABLE `perfil_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `personal`
--
ALTER TABLE `personal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `seccion`
--
ALTER TABLE `seccion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `sistema`
--
ALTER TABLE `sistema`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipo_existencia`
--
ALTER TABLE `tipo_existencia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipo_mantenimiento`
--
ALTER TABLE `tipo_mantenimiento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `unidad`
--
ALTER TABLE `unidad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cae`
--
ALTER TABLE `cae`
  ADD CONSTRAINT `fk_cae_unidad` FOREIGN KEY (`unidad_id`) REFERENCES `unidad` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `comision`
--
ALTER TABLE `comision`
  ADD CONSTRAINT `fk_comision_personal1` FOREIGN KEY (`personal_id`) REFERENCES `personal` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `comision_tipo_mantenimiento`
--
ALTER TABLE `comision_tipo_mantenimiento`
  ADD CONSTRAINT `fk_comision_has_tipo_mantenimiento_comision1` FOREIGN KEY (`comision_id`) REFERENCES `comision` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_comision_has_tipo_mantenimiento_tipo_mantenimiento1` FOREIGN KEY (`tipo_mantenimiento_id`) REFERENCES `tipo_mantenimiento` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `detalle_comision`
--
ALTER TABLE `detalle_comision`
  ADD CONSTRAINT `fk_detalle_comision_comision1` FOREIGN KEY (`comision_id`) REFERENCES `comision` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_detalle_comision_personal1` FOREIGN KEY (`personal_id`) REFERENCES `personal` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `estacion`
--
ALTER TABLE `estacion`
  ADD CONSTRAINT `fk_estacion_cae1` FOREIGN KEY (`cae_id`) REFERENCES `cae` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `grado`
--
ALTER TABLE `grado`
  ADD CONSTRAINT `fk_grado_fuerza1` FOREIGN KEY (`fuerza_id`) REFERENCES `fuerza` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `menu`
--
ALTER TABLE `menu`
  ADD CONSTRAINT `fk_menu_categoria_menu1` FOREIGN KEY (`categoria_menu_id`) REFERENCES `categoria_menu` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `parte`
--
ALTER TABLE `parte`
  ADD CONSTRAINT `fk_parte_sistema1` FOREIGN KEY (`sistema_id`) REFERENCES `sistema` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_parte_tipo_existencia1` FOREIGN KEY (`tipo_existencia_id`) REFERENCES `tipo_existencia` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `pase`
--
ALTER TABLE `pase`
  ADD CONSTRAINT `fk_pase_cae1` FOREIGN KEY (`cae_id`) REFERENCES `cae` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pase_personal1` FOREIGN KEY (`personal_id`) REFERENCES `personal` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pase_seccion1` FOREIGN KEY (`seccion_id`) REFERENCES `seccion` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pase_sistema1` FOREIGN KEY (`sistema_id`) REFERENCES `sistema` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `perfil_menu`
--
ALTER TABLE `perfil_menu`
  ADD CONSTRAINT `fk_perfil_menu_menu1` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_perfil_menu_perfil1` FOREIGN KEY (`perfil_id`) REFERENCES `perfil` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `personal`
--
ALTER TABLE `personal`
  ADD CONSTRAINT `fk_personal_estado_civil1` FOREIGN KEY (`estado_civil_id`) REFERENCES `estado_civil` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_personal_fuerza1` FOREIGN KEY (`fuerza_id`) REFERENCES `fuerza` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_personal_funcion1` FOREIGN KEY (`funcion_id`) REFERENCES `funcion` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_personal_grado1` FOREIGN KEY (`grado_id`) REFERENCES `grado` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `seccion`
--
ALTER TABLE `seccion`
  ADD CONSTRAINT `fk_seccion_estacion1` FOREIGN KEY (`estacion_id`) REFERENCES `estacion` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `sistema`
--
ALTER TABLE `sistema`
  ADD CONSTRAINT `fk_sistema_seccion1` FOREIGN KEY (`seccion_id`) REFERENCES `seccion` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `tipo_existencia`
--
ALTER TABLE `tipo_existencia`
  ADD CONSTRAINT `fk_tipo_existencia_cae1` FOREIGN KEY (`cae_id`) REFERENCES `cae` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `fk_usuario_personal1` FOREIGN KEY (`personal_id`) REFERENCES `personal` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `usuario_perfil`
--
ALTER TABLE `usuario_perfil`
  ADD CONSTRAINT `fk_usuario_has_perfil_perfil1` FOREIGN KEY (`perfil_id`) REFERENCES `perfil` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_usuario_has_perfil_usuario1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
